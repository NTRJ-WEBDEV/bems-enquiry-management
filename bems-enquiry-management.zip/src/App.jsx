import React, { useState } from 'react';
import { Card, CardContent } from './components/ui/card';
import { Button } from './components/ui/button';

const initialEnquiries = [
  {
    id: 1,
    name: 'John Doe',
    subject: 'High Energy Bill',
    description: 'Energy consumption unusually high this month.',
    status: 'Open',
  },
];

export default function App() {
  const [enquiries, setEnquiries] = useState(initialEnquiries);
  const [form, setForm] = useState({ name: '', subject: '', description: '' });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const newEnquiry = {
      id: enquiries.length + 1,
      ...form,
      status: 'Open',
    };
    setEnquiries([...enquiries, newEnquiry]);
    setForm({ name: '', subject: '', description: '' });
  };

  const updateStatus = (id, newStatus) => {
    const updated = enquiries.map((e) =>
      e.id === id ? { ...e, status: newStatus } : e
    );
    setEnquiries(updated);
  };

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">BEMS Enquiry Management</h1>

      <form onSubmit={handleSubmit} className="space-y-3 mb-6 bg-white p-4 rounded shadow">
        <input
          name="name"
          value={form.name}
          onChange={handleChange}
          placeholder="Your Name"
          className="w-full p-2 border rounded"
          required
        />
        <input
          name="subject"
          value={form.subject}
          onChange={handleChange}
          placeholder="Subject"
          className="w-full p-2 border rounded"
          required
        />
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          placeholder="Description"
          className="w-full p-2 border rounded"
          required
        />
        <Button type="submit">Submit Enquiry</Button>
      </form>

      <div className="space-y-4">
        {enquiries.map((enq) => (
          <Card key={enq.id} className="shadow">
            <CardContent className="p-4 space-y-2">
              <div className="font-semibold text-lg">{enq.subject}</div>
              <div className="text-gray-700">{enq.description}</div>
              <div className="text-sm text-gray-500">By: {enq.name}</div>
              <div className="text-sm font-medium">
                Status: <span className="text-blue-600">{enq.status}</span>
              </div>
              <div className="flex space-x-2 mt-2">
                {['Open', 'In Progress', 'Closed'].map((status) => (
                  <Button
                    key={status}
                    onClick={() => updateStatus(enq.id, status)}
                    variant="outline"
                    size="sm"
                  >
                    {status}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}